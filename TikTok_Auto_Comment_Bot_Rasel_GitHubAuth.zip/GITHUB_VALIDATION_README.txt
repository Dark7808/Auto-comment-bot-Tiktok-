
GitHub Access Key Validation Instructions
-----------------------------------------

1. Create a GitHub repository (can be private or public) and add a file named 'keys.json' in the main branch.
   Example content:
   {
     "valid_keys": ["RASEL-USER-001", "RASEL-USER-002"]
   }

2. Get the RAW URL for the file. Example raw URL:
   https://raw.githubusercontent.com/your-username/your-repo/main/keys.json

3. Open popup.js inside the extension folder and replace the VALIDATION_URL value with your raw URL:
   const VALIDATION_URL = "https://raw.githubusercontent.com/your-username/your-repo/main/keys.json";

4. Save and zip the folder, then install as 'Load unpacked' in chrome://extensions/

Note: If the extension cannot reach GitHub, it will try local fallback keys (from keys_local_backup.json) if present.
