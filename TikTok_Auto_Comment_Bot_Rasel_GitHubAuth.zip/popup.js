// Online GitHub-based Access Key validation with local fallback
// IMPORTANT: Replace VALIDATION_URL with your raw GitHub URL to keys.json
// Example: https://raw.githubusercontent.com/your-username/tiktok-access-keys/main/keys.json
const VALIDATION_URL = "https://raw.githubusercontent.com/<your-username>/<your-repo>/main/keys.json";
const ACCESS_KEY_STORAGE = 'rasel_access_key';
const ACCESS_GRANTED = 'rasel_access_granted';

async function fetchRemoteKeys(url, timeout = 5000) {
  try {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(id);
    if (!res.ok) throw new Error('Network response not OK');
    const data = await res.json();
    return data.valid_keys || data.authorized_keys || [];
  } catch (e) {
    console.warn('Remote keys fetch failed:', e.message || e);
    return null; // indicate remote fetch failed
  }
}

async function loadLocalKeys() {
  try {
    const res = await fetch(chrome.runtime.getURL('keys.json'));
    const data = await res.json();
    return data.valid_keys || data.authorized_keys || [];
  } catch (e) {
    console.warn('Local keys load failed:', e.message || e);
    return [];
  }
}

function setStatus(text, ok=false){
  const statusEl = document.getElementById('status');
  if(statusEl){ statusEl.textContent = 'Status: ' + text; statusEl.style.color = ok ? '#28a745' : '#9aa4b2'; }
}

function showOverlay() {
  const o = document.getElementById('accessOverlay');
  if (o) o.style.display = 'flex';
}

function hideOverlay() {
  const o = document.getElementById('accessOverlay');
  if (o) o.style.display = 'none';
}

async function validateKeyOnlineOrLocal(userKey) {
  // Try remote (GitHub) first
  const remote = await fetchRemoteKeys(VALIDATION_URL, 6000);
  if (Array.isArray(remote)) {
    if (remote.includes(userKey)) return true;
    // remote responded but key not present
    return false;
  }
  // remote failed -> try local keys.json as fallback (if present)
  const local = await loadLocalKeys();
  if (local.includes(userKey)) return true;
  return false;
}

document.addEventListener('DOMContentLoaded', ()=>{
  const submit = document.getElementById('accessSubmit');
  const cancel = document.getElementById('accessCancel');
  const input = document.getElementById('accessKeyInput');
  const msg = document.getElementById('accessMsg');
  const storedPromise = new Promise(resolve => chrome.storage.local.get([ACCESS_KEY_STORAGE, ACCESS_GRANTED], r => resolve(r)));

  // If already granted, hide overlay
  storedPromise.then(stored => {
    if (stored && stored[ACCESS_GRANTED]) {
      hideOverlay();
      setStatus('Access granted. Ready.', true);
    } else {
      showOverlay();
    }
  });

  if(submit){
    submit.addEventListener('click', async ()=>{
      const key = input.value && input.value.trim();
      if(!key){ msg.textContent = 'Please enter a key.'; return; }
      setStatus('Verifying key...');
      try {
        const ok = await validateKeyOnlineOrLocal(key);
        if (ok) {
          chrome.storage.local.set({[ACCESS_KEY_STORAGE]: key, [ACCESS_GRANTED]: true}, ()=>{
            hideOverlay();
            setStatus('Access granted. Ready.', true);
          });
        } else {
          msg.textContent = 'Invalid key! Contact Rasel for permission.';
          setStatus('Access denied', false);
        }
      } catch (e) {
        msg.textContent = 'Verification error. Try again later.';
        setStatus('Verification error', false);
      }
    });
  }
  if(cancel){
    cancel.addEventListener('click', ()=>{ window.close(); });
  }
});

// --- Bot logic (unchanged) ---
let timerId = null;
let attempts = 0;
let maxAttempts = 0;

const startBtn = document.getElementById('start');
const stopBtn = document.getElementById('stop');

startBtn && startBtn.addEventListener('click', async () => {
  const comment = document.getElementById('comment').value.trim();
  let interval = parseInt(document.getElementById('interval').value, 10);
  if(!comment){ setStatus('Please enter a comment', false); return; }
  if(isNaN(interval) || interval < 2) interval = 2;
  const stored = await new Promise(resolve => chrome.storage.local.get([ACCESS_GRANTED], r => resolve(r)));
  if(!stored || !stored[ACCESS_GRANTED]){
    setStatus('Access key required', false);
    showOverlay();
    return;
  }
  setStatus('Starting...');
  attempts = 0;
  maxAttempts = Math.ceil(60 / interval);
  await runComment(comment);
  timerId = setInterval(()=> runComment(comment), interval * 1000);
});

stopBtn && stopBtn.addEventListener('click', () => {
  if(timerId) clearInterval(timerId);
  timerId = null;
  setStatus('Stopped', false);
});

async function runComment(comment){
  if(timerId === null && attempts>0) return;
  attempts++;
  if(attempts > maxAttempts){
    setStatus('Timeout reached, stopped', false);
    if(timerId) { clearInterval(timerId); timerId = null; }
    return;
  }
  setStatus(`Posting... (attempt ${attempts}/${maxAttempts})`);
  try{
    const tabs = await chrome.tabs.query({active:true,currentWindow:true});
    if(!tabs || !tabs[0]) { setStatus('No active tab', false); return; }
    const tabId = tabs[0].id;
    const res = await chrome.scripting.executeScript({
      target:{tabId},
      func: injectedCommentFunction,
      args:[comment]
    });
    const ok = res && res[0] && res[0].result === true;
    if(ok){
      setStatus('Comment sent ✅', true);
    } else {
      setStatus('Attempt failed (selector mismatch) — will retry', false);
    }
  }catch(e){
    console.error(e);
    setStatus('Error: ' + e.message, false);
  }
}

function injectedCommentFunction(comment){
  try{
    const selectors = [
      'textarea',
      'div[contenteditable=\"true\"]',
      'div.public-DraftStyleDefault-block'
    ];
    let input = null;
    for(const s of selectors){
      input = document.querySelector(s);
      if(input) break;
    }
    if(!input) return false;
    input.focus();
    if(input.tagName.toLowerCase() === 'textarea' || input.tagName.toLowerCase() === 'input'){
      input.value = comment;
      input.dispatchEvent(new Event('input', {bubbles:true}));
    } else {
      input.innerText = comment;
      input.dispatchEvent(new InputEvent('input', {bubbles:true}));
    }
    const btnCandidates = Array.from(document.querySelectorAll('button,div[role=\"button\"],a'));
    let postBtn = null;
    for(const b of btnCandidates){
      const txt = (b.innerText || '').trim().toLowerCase();
      if(txt.includes('post') || txt.includes('send') || txt.includes('comment') || txt.includes('reply')){
        postBtn = b; break;
      }
      const al = (b.getAttribute && b.getAttribute('aria-label') || '').toLowerCase();
      if(al.includes('post')||al.includes('send')||al.includes('comment')){ postBtn = b; break; }
    }
    if(postBtn){
      postBtn.click();
      return true;
    }
    const e = new KeyboardEvent('keydown', {key:'Enter',bubbles:true});
    input.dispatchEvent(e);
    return true;
  }catch(err){
    return false;
  }
}
